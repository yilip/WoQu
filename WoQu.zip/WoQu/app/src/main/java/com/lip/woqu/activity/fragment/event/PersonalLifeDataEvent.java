package com.lip.woqu.activity.fragment.event;

/**
 *  2015/1/17.
 *  用于更新个人中心中的life数量
 */
public class PersonalLifeDataEvent {
}
