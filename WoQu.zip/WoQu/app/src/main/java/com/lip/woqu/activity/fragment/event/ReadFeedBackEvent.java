package com.lip.woqu.activity.fragment.event;

/**
 * Created by admin on
 * 2015/3/13.
 */
public class ReadFeedBackEvent {
}