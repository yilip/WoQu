package com.lip.woqu.activity;

import android.os.Bundle;

import com.lip.woqu.EFragmentActivity;
import com.lip.woqu.R;

public class UserFeedbackActivity extends EFragmentActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_feedback);
    }
}
