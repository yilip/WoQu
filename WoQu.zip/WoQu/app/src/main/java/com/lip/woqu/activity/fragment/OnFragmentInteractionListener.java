package com.lip.woqu.activity.fragment;

import android.net.Uri;

public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        public void onFragmentInteraction(Uri uri);
    }