package com.lip.woqu.utils;


public class SysParams
{
    //接口地址
    public  static String baseUrl="http://www.lipyi.com/WoQu/";
    //所有活动
    public static String ACTIVITIES_URL=baseUrl+"activities";
    //活动详情
    public static String ACTIVITITY_URL=baseUrl+"activity";
    //个人资料
    public static String MYPROFILE_URL=baseUrl+"myprofile";

    public static String uploadFileURL=baseUrl+"upload";
    //发布活动
    public static String PUBLISH_URL=baseUrl+"publish";
    //我发布的活动
    public static String MYPUBLISH_URL=baseUrl+"mypublish";
    //参与活动
    public static String APPLY_URL=baseUrl+"apply";
    //收藏活动
    public static String COLLECT_URL=baseUrl+"collect";
    public static int userId=10001;
}
