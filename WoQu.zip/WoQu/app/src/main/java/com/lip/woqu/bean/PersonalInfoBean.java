package com.lip.woqu.bean;

import java.io.Serializable;

/**
 * Created by admin on 2015/3/6.
 */
public class PersonalInfoBean implements Serializable {
    public String nickName;//昵称
    public int uId;
    public String phone;
    public String gender;
    public String avatar;
}
